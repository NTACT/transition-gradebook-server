module.exports = `
    .risk-indicator {
        -webkit-align-self: flex-start;
        width: 0; 
        height: 0; 
        border-left: 16px solid transparent;
        border-right: 16px solid transparent;
        border-top: 16px solid black;
    }
`;
