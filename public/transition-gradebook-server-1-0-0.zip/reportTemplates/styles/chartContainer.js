module.exports = `
    .chart-container {
        display: -webkit-flex;
        -webkit-justify-content: space-around;
        overflow: visible;
    }
`;
