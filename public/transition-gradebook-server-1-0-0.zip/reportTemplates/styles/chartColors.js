module.exports = [
  '#A20B0E',
  '#4A4A4A',
  '#D43425',
  '#9B9B9B',
  '#F5633A',
  'black',
  '#FCB32F',
];

module.exports.horizontalBarColors = [
  '#A20B0E',
  '#F5633A',
]

module.exports.pieChartColors = [
  '#A20B0E',
  '#D43425',
  '#4A4A4A',
];
