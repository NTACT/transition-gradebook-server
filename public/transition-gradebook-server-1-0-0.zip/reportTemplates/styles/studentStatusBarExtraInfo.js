module.exports = `
  .risk-student-extra {
    display: -webkit-flex;
    -webkit-justify-content: flex-end;
    font-size: 12px;
  }

  .risk-student-extra-item {
    display: -webkit-flex;
    -webkit-align-items: center;
    margin-left: 20px;
  }

  .risk-student-extra-value {
    font-size: 11px;
    color: #D43425;
    margin-left: 10px;
  }
`;
