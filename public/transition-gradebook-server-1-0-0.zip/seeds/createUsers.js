module.exports = function createUsers({ models }) {
  return models.User.query().insert([
    {
      firstName: 'test',
      lastName: 'user',
      email: 'user@test.com',
      password: 'password',
      admin: false,
    },
    {
      firstName: 'test',
      lastName: 'admin',
      email: 'admin@test.com',
      password: 'password',
      admin: true,
    },
  ]);
};
