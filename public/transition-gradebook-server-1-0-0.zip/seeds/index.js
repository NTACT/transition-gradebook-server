const createTestData = (
  process.env.NODE_ENV === 'development' ||
  process.env.NODE_ENV === 'test'
);

module.exports = [
  require('./createActivityTypes'),
  require('./createDisabilities'),
  require('./createUsers'),
  require('./createSchoolSettings'),
  createTestData && require('./createSchoolYears'),
  createTestData && require('./createActivities'),
].filter(v => !!v);
