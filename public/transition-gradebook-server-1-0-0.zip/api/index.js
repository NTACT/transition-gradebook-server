module.exports = context => {
  const { Router } = context;

  return Router()
    .use(require('./dashboard')(context))
    .use(require('./disabilities')(context))
    .use(require('./schoolYears')(context))
    .use(require('./students')(context))
    .use(require('./users')(context))
    .use(require('./reports')(context))
    .use(require('./schoolSettings')(context))
    .use(require('./activities')(context));
};
