
module.exports = context => {
  const { Router, middleware, controllers } = context;
  const { ActivityController } = controllers;
  const { requireAuthToken } = middleware;

  return Router()

    .get('/activities/groups', requireAuthToken(), async (req, res) => {
      res.success({
        activityTypeGroups: await ActivityController.getTypeGroups()
      });
    })

    .get('/activities/:studentId/:schoolYearId', requireAuthToken(), async (req, res) => {
      const studentId = +req.params.studentId;
      const schoolYearId = +req.params.schoolYearId;

      res.success({
        activities: await ActivityController.getStudentActivities(studentId, schoolYearId)
      });
    })

    .post('/activities/:studentId/:schoolYearId', requireAuthToken(), async (req, res) => {
      const studentId = +req.params.studentId;
      const schoolYearId = +req.params.schoolYearId;
      const fields = {
        ...req.body,
        studentId,
        schoolYearId,
      };

      res.success({
        activity: await ActivityController.createActivity(fields),
      });
    })

    .post('/activities/:studentId/:schoolYearId/:activityId', requireAuthToken(), async (req, res) => {
      const activityId = +req.params.activityId;
      const studentId = +req.params.studentId;
      const schoolYearId = +req.params.schoolYearId;
      const fields = {
        ...req.body,
        studentId,
        schoolYearId
      };

      res.success({
        activity: await ActivityController.editActivity(activityId, fields),
      });
    })

    .delete('/activities/:activityId', requireAuthToken(), async (req, res) => {
      const activityId = +req.params.activityId;
      await ActivityController.deleteActivity(activityId);
      res.success();
    })

};
