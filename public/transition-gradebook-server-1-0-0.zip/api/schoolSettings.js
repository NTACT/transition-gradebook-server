module.exports = context => {
  const { Router, middleware, controllers } = context;
  const { requireAuthToken } = middleware;

  return Router()
    .get('/schoolSettings', requireAuthToken(), async (req, res) => {
      res.success({
        schoolSettings: await controllers.SchoolSettingsController.getSchoolSettings()
      });
    })
    .post('/schoolSettings', requireAuthToken(), async (req, res) => {
      res.success({
        schoolSettings: await controllers.SchoolSettingsController.updateSchoolSettings(req.body)
      });
    });

};
