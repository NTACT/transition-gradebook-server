module.exports = context => {
  const nodemailer = require('nodemailer');
  const uuid = require('uuid/v1');
  const bcrypt = require('bcrypt');
  const filter = require('array-promise-filter');
  const adminOnly = require('../utils/adminOnly');
  const { Router, middleware, controllers, models } = context;
  const { User, ResetPassword } = models;
  const { UserController, ResetPasswordController } = controllers;
  const { requireAuthToken } = middleware;

  function hashAndInsertPasswordRequestIdentifier(user, uid) {
    const saltRounds = 10;
    let hash = null;
    return bcrypt.hash(uid, saltRounds)
      .then(result =>  {
        hash = result;
        return ResetPasswordController.deleteUniqueIdentifier(user)
      })
      .then(() => hash && ResetPasswordController.insertUniqueIdentifier(user, hash));
  };

  async function checkPasswordRequestIdentifier(uid, returnData=false) {
    const getPasswordRequests = await ResetPasswordController.getUniqueIdentifiers();

    const requestExists = await filter(getPasswordRequests, (passwordRequest) => bcrypt.compare(uid, passwordRequest.uid)).then(res => res);
    if (requestExists.length === 0) return { valid: false, message: 'Invalid reset password link' };

    const { createdAt } = requestExists[0];
    const expirationLimit = new Date(createdAt);
    expirationLimit.setDate(expirationLimit.getDate() + 1);
    if (new Date () > expirationLimit) return { valid: false, message: 'This reset password link has expired' };

    if (returnData) return { valid: true, user: requestExists[0] };

    return { valid: true };
  }

  return Router()
    .post('/login', middleware.login(User))
    .get('/user', requireAuthToken(), middleware.getUser())
    .get('/users', requireAuthToken(), async (req, res) => {
      res.success({
        users: await UserController.getUsers()
      });
    })
    .post('/users', requireAuthToken(), adminOnly(), async (req, res) => {
      res.success({
        user: await UserController.createUser(req.body)
      });
    })
    .post('/users/:userId', requireAuthToken(), async (req, res) => {
      const user = req.user;
      const userId = +req.params.userId;
      const fields = {...req.body};

      // Only admins can edit users other than themselves
      if(!user.admin) {
        if(user.id !== userId) {
          return res.fail('Only admins can edit other user\'s profiles', 401);
        } else {
          fields.admin = false; // make sure users can't make themselves admin when updating their profile
        }
      }

      res.success({
        user: await UserController.updateUser(userId, fields)
      });
    })
    .delete('/users/:userId', requireAuthToken(), adminOnly(), async (req, res) => {
      const userId = +req.params.userId;
      await UserController.deleteUser(userId);
      res.success();
    })

    .post('/forgotPassword', async (req, res) => {
      const { username } = req.body;

      const user = await UserController.getUser(username);
      if (!user) {
        return res.fail('This user does not exist.', 401);
      }

      const { siteUrl, emailService } = context.config;
      if (!emailService) {
        console.error(`Error: Email service is not defined in your configuration file. Could not send reset password email to ${username}.`)
        return res.fail("Email configuration error. Please contact your system administrator.", 500);
      }

      if (!siteUrl) {
        console.error(`Error: Site URL is missing from the configuration file. This field is required. Reset password email was not sent to ${username}.`)
        return res.fail("Email configuration error. Please contact your system administrator.", 500);
      }

      const { fromEmail, ...transporterOptions } = emailService;
      const transporter = nodemailer.createTransport(transporterOptions);

      const uid = uuid();
      await hashAndInsertPasswordRequestIdentifier(user, uid)
        .catch(error => {
          console.error(error);
          return res.fail("Email configuration error. Please contact your system administrator.", 500);
      });

      const resetLink = `${siteUrl}#ResetPassword/${uid}`;

      const mailOptions = {
        from: fromEmail,
        to: username,
        subject: 'Transition Gradebook - Reset password',
        html:
          `
            <p>You are receiving this email because you have requested to reset the password of your Transition Gradebook user account.</p>
            <p>Click or copy/paste the following link to reset your password: <a href="${resetLink}">${resetLink}</a>.</p>
            <p>This link will expire within 24 hours.</p>
            <p>If you did not request this, please ignore this email and your password will remain unchanged.</p>
          `
      };

      transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
          console.error(`An error occurred while sending an email to ${username}. See error details below.\n`, error);
          return res.fail('The email service was unable to send an email.', 500);
        }
        else {
          res.success({ message: `An email was sent to ${username}.`, uid: uid});
        }
      });
    })

    .get('/checkResetPasswordRequest', async (req, res) => {
      const { uid } = req.query;
      if (!uid) {
        console.error('Invalid request. No unique identifier.');
        return res.fail('Invalid request. No unique identifier.', 401);
      }

      const checkPasswordRequestResult = await checkPasswordRequestIdentifier(uid);
      return res.send(checkPasswordRequestResult);
    })

    .post('/resetPassword', async (req, res) => {
      const {
        uid,
        password,
      } = req.body;

      if (!uid || !password) {
        console.error('Invalid request. No password or no unique identifier.');
        return res.fail('Invalid request. No password or no unique identifier.', 401);
      }

      const checkPasswordRequestResult = await checkPasswordRequestIdentifier(uid, true);
      if (!checkPasswordRequestResult.valid) {
        return res.fail('Invalid request.', 401);
      }

      const {user} = checkPasswordRequestResult;
      const {userId} = user;
      await UserController.updatePassword(userId, password);
      await ResetPasswordController.deleteUniqueIdentifier(user);
      return res.send({ valid: true, message: 'Password successfully reset. You may log in with your new password.' });
    });
};
