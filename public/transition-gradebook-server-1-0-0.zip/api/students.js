module.exports = context => {
  const { Router, middleware, models, controllers } = context;
  const { StudentController } = controllers;
  const { requireAuthToken } = middleware;  

  return Router()
    .delete('/students/:studentId', requireAuthToken(), async (req, res) => {
      const studentId = +req.params.studentId;
      await StudentController.deleteStudent(studentId);
      res.success();
    })
    .get('/students/:studentId/termInfo/:termId', requireAuthToken(), async (req, res) => {
      const studentId = +req.params.studentId;
      const termId = +req.params.termId;
      res.success({
        studentTermInfo: await StudentController.getStudentTermInfo(studentId, termId)
      });
    })
    .post('/studentTermInfo/:studentTermInfoId', requireAuthToken(), async (req, res) => {
      const studentTermInfoId = +req.params.studentTermInfoId;
      res.success({
        studentTermInfo: await StudentController.updateStudentTermInfo(studentTermInfoId, req.body)
      });
    });
};
