module.exports = context => {
  const adminOnly = require('../utils/adminOnly');
  const { Router, middleware, models, controllers } = context;
  const { SchoolYearController, StudentController } = controllers;
  const { requireAuthToken } = middleware;

  return Router()
    .get('/schoolYears', requireAuthToken(), async (req, res) => {
      res.success({
        schoolYears: await SchoolYearController.getSchoolYears()
      });
    })
    .post('/schoolYears', requireAuthToken(), adminOnly(), async (req, res) => {
      res.success({
        schoolYear: await SchoolYearController.createSchoolYear(req.body)
      });
    })
    .get('/schoolYears/:schoolYearId', requireAuthToken(), async (req, res) => {
      const schoolYearId = +req.params.schoolYearId;
      res.success({
        schoolYear: await SchoolYearController.getSchoolYear(schoolYearId)
      });
    })
    .get('/schoolYears/:schoolYearId/students', requireAuthToken(), async (req, res) => {
      const schoolYearId = +req.params.schoolYearId;
      res.success({
        students: await StudentController.getStudentsBySchoolYear(schoolYearId)
      });
    })
    .post('/schoolYears/:schoolYearId/students', requireAuthToken(), async (req, res) => {
      const schoolYearId = +req.params.schoolYearId;
      res.success({
        studentTermInfos: await StudentController.createStudent(schoolYearId, req.body)
      });
    })
    .delete('/schoolYears/:schoolYearId/students/:studentId', requireAuthToken(), async (req, res) => {
      const schoolYearId = +req.params.schoolYearId;
      const studentId = +req.params.studentId;
      await StudentController.removeStudentFromYear(studentId, schoolYearId, req.body);
      res.success();
    })
    .post('/schoolYears/:schoolYearId/students/:studentId', requireAuthToken(), async (req, res) => {
      const schoolYearId = +req.params.schoolYearId;
      const studentId = +req.params.studentId;
      res.success({
        studentTermInfos: await StudentController.editStudent(studentId, schoolYearId, req.body)
      });
    })
    .post('/schoolYears/:schoolYearId/export', requireAuthToken(), async (req, res) => {
      const schoolYearId = +req.params.schoolYearId;
      const studentIds = req.body.studentIds;
      res.success(await StudentController.getExportData(schoolYearId, studentIds));
    })
    .get('/term/:termId/students', requireAuthToken(), async (req, res) => {
      const termId = +req.params.termId;
      res.success({
        students: await SchoolYearController.getStudentsByTerm(termId)
      });
    });
};
