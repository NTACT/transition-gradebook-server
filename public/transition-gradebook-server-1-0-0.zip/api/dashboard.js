module.exports = context => {
  const { Router, middleware, controllers } = context;
  const { requireAuthToken } = middleware;

  return Router()
    .get('/dashboard/:termId', requireAuthToken(), async (req, res) => {
      const termId = +req.params.termId;
      res.success(
        await controllers.DashboardController.getDashboardDataForTerm(termId)
      );
    });
};
