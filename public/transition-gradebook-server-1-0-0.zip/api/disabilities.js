module.exports = context => {
  const { Router, middleware, controllers } = context;
  const { requireAuthToken } = middleware;

  return Router()
    .get('/disabilities', requireAuthToken(), async (req, res) => {
      res.success({
        disabilities: await controllers.DisabilityController.getDisabilities()
      });
    });
};
