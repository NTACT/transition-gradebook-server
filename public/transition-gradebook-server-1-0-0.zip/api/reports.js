module.exports = context => {
  const { Router, middleware, controllers } = context;
  const createPDF = require('../utils/createPDF');
  const timeout = 1000 * 60 * 10; // ten minutes

  return Router()
    .get('/reports/summary', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const reportName = 'summary';
      const template = require('../reportTemplates/summaryReport');
      const { startYearId, startTermId } = req.query;
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    })

    .get('/reports/riskRoster', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const reportName = 'riskRoster';
      const template = require('../reportTemplates/riskRosterReport');
      const { startYearId, startTermId } = req.query;
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    })

    .get('/reports/riskSummary', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const reportName = 'riskSummary';
      const template = require('../reportTemplates/riskSummaryReport');
      const { startYearId, startTermId, endYearId, endTermId } = req.query;
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
        endYearId: +endYearId,
        endTermId: +endTermId,
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    })

    .get('/reports/numberOfStudents/standard', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const reportName = 'numberOfStudentsStandard';
      const template = require('../reportTemplates/numberOfStudentsStandard');
      const {
        startYearId,
        startTermId,
        byPostSchoolOutcome,
        byRiskLevel,
        bySkillTraining,
        bySupportNeed,
        byIEPRole,
        byDisability,
        byActivityGroupTypes,
      } = req.query;
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
        byPostSchoolOutcome: byPostSchoolOutcome === 'true',
        byRiskLevel: byRiskLevel === 'true',
        bySkillTraining: bySkillTraining === 'true',
        bySupportNeed: bySupportNeed === 'true',
        byIEPRole: byIEPRole === 'true',
        byDisability: byDisability === 'true',
        byActivityGroupTypes: byActivityGroupTypes === 'true',
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    })

    .get('/reports/numberOfStudents/longitudinal', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const reportName = 'numberOfStudentsLongitudinal';
      const template = require('../reportTemplates/numberOfStudentsLongitudinal');
      const {
        startYearId,
        startTermId,
        endYearId,
        endTermId,
        byPostSchoolOutcome,
        byRiskLevel,
        bySkillTraining,
        bySupportNeed,
        byIEPRole,
        byDisability,
        byActivityGroupTypes,
      } = req.query;
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
        endYearId: +endYearId,
        endTermId: +endTermId,
        byPostSchoolOutcome: byPostSchoolOutcome === 'true',
        byRiskLevel: byRiskLevel === 'true',
        bySkillTraining: bySkillTraining === 'true',
        bySupportNeed: bySupportNeed === 'true',
        byIEPRole: byIEPRole === 'true',
        byDisability: byDisability === 'true',
        byActivityGroupTypes: byActivityGroupTypes === 'true',
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    })

    .get('/reports/student', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const {
        startYearId,
        startTermId,
        studentId,
      } = req.query;

      const template = require('../reportTemplates/studentReport');
      const reportName = 'student';
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
        studentIds: studentId ? [+studentId] : null,
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    })

    .get('/reports/studentRisk/standard', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const {
        startYearId,
        startTermId,
        studentId,
      } = req.query;

      const template = require('../reportTemplates/studentRiskStandardReport');
      const reportName = 'studentRiskStandard';
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
        studentIds: studentId ? [+studentId] : null,
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    })

    .get('/reports/studentRisk/longitudinal', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const {
        startYearId,
        startTermId,
        endYearId,
        endTermId,
        studentId,
      } = req.query;

      const template = require('../reportTemplates/studentRiskLongitudinalReport');
      const reportName = 'studentRiskLongitudinal';
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
        endYearId: +endYearId,
        endTermId: +endTermId,
        studentIds: studentId ? [+studentId] : null,
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    })

    .get('/reports/postSchoolStudent', middleware.requireAuthToken(), async (req, res) => {
      req.setTimeout(timeout);
      const {
        startYearId,
        startTermId,
        studentId,
      } = req.query;

      const template = require('../reportTemplates/postSchoolStudentReport');
      const reportName = 'postSchoolStudent';
      const options = {
        startYearId: +startYearId,
        startTermId: +startTermId,
        studentIds: studentId ? [+studentId] : null,
      };
      const data = await controllers.ReportController.runReport(reportName, options);
      const html = template(data);
      const stream = await createPDF(html);
      stream.pipe(res);
    });

};
