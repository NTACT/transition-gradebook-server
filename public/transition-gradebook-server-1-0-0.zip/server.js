const NRBP = require('./core');

module.exports = new NRBP(
  require('./config/config.default'),
  process.env.NODE_ENV === 'test' 
    ? require('./config/config.test')
    : require('./config/config'),
  {rootDir: __dirname}
)
  .withArgv(process.argv)
  .withKnexMigrations('./migrations')
  .withSeeds(require('./seeds'))
  .withApi(require('./api'))
  .withModels(require('./models'))
  .withControllers(require('./controllers'));
