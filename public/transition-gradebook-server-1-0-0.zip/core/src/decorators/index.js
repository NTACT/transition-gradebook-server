module.exports = context => ({
  bind: require('bind-decorator'),
  hasPassword: require('./hasPassword')(context),
  transaction: require('./transaction')(context),
  uniqueFields: require('./uniqueFields')(context),
  visibility: require('./visibility')(context),
});
