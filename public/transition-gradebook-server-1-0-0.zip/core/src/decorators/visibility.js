module.exports = context => {

  const visibility = require('objection-visibility');
  return Model => class extends visibility(Model) {
    static get name() { return Model.name; }
  };

}
