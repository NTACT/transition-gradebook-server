module.exports = context => {

  const unique = require('objection-unique');
  return (...fields) => {
    const uniquePlugin = unique({fields});
    return (Model) => class extends uniquePlugin(Model) {
      static get name() { return Model.name; }
    };
  };

};
