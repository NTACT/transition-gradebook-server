module.exports = context => {

  const { config } = context;
  const objectionPassword = require('objection-password');
  const visibility = require('./visibility')(context);
  const { ValidationError } = context.objection;

  return (Model) => {
    const passwordField = (Model.passwordField || config.defaultPasswordField);

    const passwordPluginOptions = {
      passwordField: passwordField,
      rounds: config.passwordSaltRounds
    };
    const ModelWithPlugins = visibility(objectionPassword(passwordPluginOptions)(Model));
    const modelHidden = Model.hidden;
    const hiddenFields = modelHidden ? modelHidden.concat(passwordField) : [passwordField];

    return class extends ModelWithPlugins {
      static get name() { return Model.name; }
      static get hidden() { return hiddenFields; }

      async generateHash() {
        const password = this[passwordField];
        if(!password) throw createMissingPasswordError(passwordField);

        return super.generateHash();
      }
    }
  };

  function createMissingPasswordError(passwordField) {
    const type = 'ModelValidation';
    const message = 'Required';
    const data = {
      [passwordField]: [{
        message,
        keyword: 'required',
        params: null,
      }],
    };

    return new ValidationError(data);
  }

};
