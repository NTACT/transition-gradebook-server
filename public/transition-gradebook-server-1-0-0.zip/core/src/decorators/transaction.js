// Method decorator for automatically wrapping a method body in a database transaction.
module.exports = context => {
  const { knex } = context;
  const { transaction } = context.objection;

  return function transactionDecorator(target, key, descriptor) {
    const method = descriptor.value;
    return {
      ...descriptor,
      value(...args) {
        return transaction(knex, t => {
          return method.call(this, t, ...args);
        });
      }
    };
  };

};
  