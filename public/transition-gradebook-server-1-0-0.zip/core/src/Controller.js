module.exports = context => {
  const enableHardName = require('./utils/enableHardName');
  const bindMethods = require('./utils/bindMethods');

  @enableHardName('controllerId')
  class Controller {
    constructor() {
      bindMethods(this);
    }
  }

  return Controller;
};
