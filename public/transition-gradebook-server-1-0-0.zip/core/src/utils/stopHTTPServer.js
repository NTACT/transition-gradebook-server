
module.exports = function stopHTTPServer(server) {
  return new Promise((resolve) => {
    server.close()
      .on('close', resolve)
      .on('error', resolve);
  });
};
