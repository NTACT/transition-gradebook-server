const { isAbsolute, join } = require('path');

/*
  Takes a `rootPath`, a `filePath`, and an optional `defaultFilePath`.
  Returns `filePath` if it exists otherwise returns `defaultFilePath`.
  If the return value (`filePath`/`defaultFilePath`) is a relative path,
  it is resolved relative to `rootPath`.
  If neither `filePath` or `defaultFilePath` are provided, `null` is returned.

  examples:

    // Relative paths
    resolveAppPath('/path/to/project', 'filename.js', 'defaultFilename.js') -> '/path/to/project/filename.js'
    resolveAppPath('/path/to/project', null, 'defaultFilename.js') -> '/path/to/project/defaultFilename.js'

    // Absolute paths
    resolveAppPath('/path/to/project', '/some/absolute/path/file.js') -> '/some/absolute/path/file.js'
    resolveAppPath('/path/to/project', null, '/default/absolute/file.js') -> '/default/absolute/file.js'

    // No inputs
    resolveAppPath('/path/to/project', null, null) -> null
*/
module.exports = function resolveAppPath(rootDir, filePath, defaultFilePath) {
  if(!filePath) {
    if(defaultFilePath) {
      filePath = defaultFilePath;
    } else {
      return null;
    }
  }

  return isAbsolute(filePath) ? filePath : join(rootDir, filePath);
}
