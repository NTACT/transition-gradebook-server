
module.exports = (passport, secretOrKey, findUser) => {
  const JwtStrategy = require('passport-jwt').Strategy;
  const options = { secretOrKey, jwtFromRequest };
  const strategy = new JwtStrategy(options, async (jwtPayload, next) => {
    try {
      const user = await findUser(jwtPayload);
      next(null, user);
    } catch(error) {
      next(error);
    }
  });
  passport.use(strategy);
  return passport.initialize();
};

function jwtFromRequest(request) {
  const Authorization = request && request.header('Authorization');
  if(!Authorization) return false;
  return Authorization.replace(/^JWT\s+/i, ''); // strip optional "JWT " from beginning of token
}
