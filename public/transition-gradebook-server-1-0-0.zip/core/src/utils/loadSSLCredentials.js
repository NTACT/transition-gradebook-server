const { exists, readFile } = require('then-fs');

module.exports = async function loadSSLCredentials(keyPath, certPath) {
  const [ keyExists, certExists ] = await Promise.all([
    exists(keyPath),
    exists(certPath),
  ]).catch(() => [false, false]);

  if(!keyExists) throw new Error(`SSL key file not found: "${keyPath}".`);
  if(!certExists) throw new Error(`SSL cert file not found: "${certPath}".`);

  const [ key, cert ] = await Promise.all([
    readFile(keyPath, 'utf8'),
    readFile(certPath, 'utf8'),
  ]);

  return { key, cert };
}
