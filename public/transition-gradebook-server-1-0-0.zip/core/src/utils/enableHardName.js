
/*
  Adds a static name to child classes that is not overwritten through inheritance.
  The main purpose of this is to keep class names from being overwritten by
  decorator classes.
  Example:

  @enableHardName()
  class Model {}

  @someDecorator
  class User extends Model {}

  console.log(User.name); // 'SomeDecoratorClass' oops
  console.log(User.hardname); // 'User' yay

  function someDecorator(Class) {
    // someDecorator extends Class to add some functionality
    return class SomeDecoratorClass extends Class {}
  }
*/


module.exports = function enableHardName(key='hardname') {
  const privateKey = '_' + key;
  return (Class) => Object.defineProperty(Class, key, {
    get() {
      if(!this[privateKey]) {
        const topLevelClass = this.topLevelClass || Class;
        if(this === topLevelClass) return topLevelClass.name;
        let parent = this;
        let target;

        do {
          target = parent;
          parent = Object.getPrototypeOf(target);
        } while(parent !== topLevelClass);

        this[privateKey] = target.name;
      }

      return this[privateKey];
    },

    set(hardName) {
      this[privateKey] = hardName;
      return hardName;
    }
  });

  return Class;
}
