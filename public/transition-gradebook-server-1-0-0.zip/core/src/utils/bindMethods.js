
/*
  Binds all methods of `object` to `object`. Example:

  class Foo {
    bar = 'bar';

    a() {
      return this.bar;
    }
  }

  const foo = new Foo();
  const aUnbound = foo.a;
  bindMethods(foo);
  const aBound = foo.a;

  aUnbound(); // undefined
  aBound(); // 'bar'
*/
module.exports = function bindMethods(object) {
  const props = Object.getOwnPropertyNames(Object.getPrototypeOf(object));
  for(let key of props) {
    if(key === 'constructor') continue;
    const value = object[key];
    if(!value || typeof value !== 'function') continue;
    object[key] = value.bind(object);
  }
  return object;
}
