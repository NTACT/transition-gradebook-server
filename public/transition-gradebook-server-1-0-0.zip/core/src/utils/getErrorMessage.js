module.exports = function getErrorMessage(error) {
  return error ? error.message || error.toString() : 'Unknown error (Missing error on server)';
}
