const promisify = require('./promisify');

module.exports = function startHTTPServer({ app, protocol, port, credentials }) {
  if(!protocol) throw new Error(`options.protocol is required ('https' or 'http').`);
  if(!port) throw new Error('options.port is required (try 8080).');
  if(protocol !== 'http' && protocol !== 'https') throw new Error(`options.protocol "${protocol}" is invalid ('https' or 'http')`)
  if(!credentials && protocol === 'https') throw new Error('Invalid credentials');

  const server = require(protocol).createServer(app, credentials)
  return promisify(server.listen, server)(port).then(() => server);
};
