module.exports = function promisify(fn, binding=null) {
  return function promisifyWrapper() {
    const { length } = arguments;
    const args = [];
    for(let i = 0; i < length; i++) {
      args.push(arguments[i]);
    }
    return new Promise((resolve, reject) => {
      args.push((error, result) => {
        if(error) reject(error);
        else resolve(result);
      });
      fn.apply(binding, args);
    });
  };
}
