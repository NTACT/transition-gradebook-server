const { merge } = require('lodash');
const createKnexInstance = require('knex');

// Connects to the 'postgres' database and drops a database.
// TODO: Fix to work with database types other than postgres
module.exports = async function dropDatabase(dbConfig) {
  const databaseName = dbConfig.connection.database;
  const knexConfig = merge({}, dbConfig, {
    connection: {
      // connect to the postgres database
      database: 'postgres'
    },
  });

  const knex = createKnexInstance(knexConfig);
  await knex.raw(`DROP DATABASE ${dbConfig.connection.database}`);
  await knex.destroy();
};
