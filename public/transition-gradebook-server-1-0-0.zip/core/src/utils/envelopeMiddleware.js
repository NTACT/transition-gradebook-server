const getErrorMessage = require('./getErrorMessage');
const { ValidationError } = require('objection');

/*
  Adds utility methods to express response objects:

  res.success(value, status=200)
  res.fail(error, status=500)
*/

const responseBuilder = defaultStatus => (res) => (data={}, status=defaultStatus) => {
  if(typeof data === 'string') {
    return res.status(status).header('Content-Type', 'text/plain').end(data);
  } else {
    return res.status(status).header('Content-Type', 'application/json').json(data);
  }
};

const success = responseBuilder(200);
const fail = responseBuilder(500);

module.exports = () => (req, res, next) => {
  res.success = success(res);
  res.fail = fail(res);
  next();
};
