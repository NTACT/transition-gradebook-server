const { merge } = require('lodash');
const createKnexInstance = require('knex');

// Connects to the 'postgres' database and creates a new database.
// TODO: Fix to work with database types other than postgres
module.exports = async function createDatabase(dbConfig) {
  const databaseName = dbConfig.connection.database;
  const knexConfig = merge({}, dbConfig, {
    connection: {
      // connect to the postgres database
      database: 'postgres'
    },
  });

  const knex = createKnexInstance(knexConfig);
  await knex.raw(`CREATE DATABASE ${databaseName}`);
  await knex.destroy();
};
