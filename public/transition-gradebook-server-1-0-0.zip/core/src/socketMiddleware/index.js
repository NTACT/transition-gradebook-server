module.exports = context => ({
  auth: require('./auth')(context),
  logout: require('./logout')(context),
  requireAuth: require('./requireAuth')(context),
});
