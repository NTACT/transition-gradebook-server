module.exports = context => {
  return function requireAuthSocketMiddleware(socket, callback) {
    if(!socket) throw new Error('Socket require auth middleware requires a socket.');
    return () => {
      if(socket.handshake.session.authenticated) {
        if(callback) callback();
      } else {
        socket.emit('not authenticated');
      }
    };
  }
};
