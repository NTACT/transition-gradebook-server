module.exports = context => {
  return function logoutSocketMiddleware(socket, callback) {
    if(!socket) throw new Error('Socket logout middleware requires a socket.');
    return () => {
      socket.handshake.session.authenticated = false;
      socket.handshake.session.user = null;
      if(callback) callback();
    };
  }
};
