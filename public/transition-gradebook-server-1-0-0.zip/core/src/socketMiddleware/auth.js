module.exports = context => {
  const jsonwebtoken = require('jsonwebtoken');

  return function jwtAuthSocketMiddleware(socket, callback) {
    if(!socket) throw new Error('Socket auth middleware requires a socket.');
    return jwt => {
      jsonwebtoken.verify(jwt, context.jwtSecret, async (error, decoded) => {
        if(error) {
          if(callback) callback(error, null);
        } else {
          const user = await context.lookupUserfromAuthToken(decoded);
          socket.handshake.session.authenticated = true;
          socket.handshake.session.user = user;
          if(callback) callback(null, user);
        }
      });
    };
  };
};
