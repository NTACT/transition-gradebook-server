module.exports = () => ({
  // Required
  rootDir: null,
  jwtSecret: null,
  jwtSecretFile: '.jwtsecret',
  logLevel: process.env['NODE_ENV'] === 'production' ? 'info' : 'debug',
  logFile: 'logs.json',

  name: 'server',
  silent: false,
  http: true,
  https: false,
  port: 8000,
  sslKeyPath: 'sslcert/server.key',
  sslCertPath: 'sslcert/server.crt',
  publicDir: 'public',
  passwordSaltRounds: 12,
  cors: false,
  database: {
    client: 'postgresql',
    connection: {
      database: '',
      user: process.env.USER || 'root',
      host: 'localhost',
      password: '',
    },
  },

  defaultUsernameField: 'email',
  defaultPasswordField: 'password',
  defaultInvalidUsernameMessage: 'That user does not exist.',
  defaultInvalidPasswordMessage: 'Incorrect password.',
  defaultMissingUsernameMessage: 'Email is required.',
  defaultMissingPasswordMessage: 'Password is required.',
});
