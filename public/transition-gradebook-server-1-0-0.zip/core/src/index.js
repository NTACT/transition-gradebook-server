const { version } = require('../package');
const path = require('path');
const EventEmitter = require('events');
const { merge, flatten } = require('lodash');
const { exists, readFile, writeFile } = require('then-fs'); // promise wrapped fs
const mkdirp = require('mkdirp');
const uuidv4 = require('uuid/v4'); // for generating JWT secret
const objection = require('objection'); // database ORM
const createKnex = require('knex'); // database query builder
const bunyan = require('bunyan'); // JSON logging
const PrettyStream = require('bunyan-prettystream'); // Bunyan log to console for dev
const expressBunyanLogger = require('express-bunyan-logger'); // Bunyan request logging
const express = require('express');
const PromiseRouter = require('express-promise-router');
const session = require('express-session');
const bodyParser = require('body-parser');
const passport = require('passport');

const getErrorMessage = require('./utils/getErrorMessage'); // Find a way to turn an error into a string
const bindMethods = require('./utils/bindMethods'); // Autobind a class's methods to itself
const testDatabaseConnection = require('./utils/testDatabaseConnection'); // Check if a knex instance has a valid database connection (used to check if the database has been created)
const createDatabase = require('./utils/createDatabase'); // Connect to postgres, run a `CREATE DATABASE` command, and close the connection
const dropDatabase = require('./utils/dropDatabase'); // Connect to postgres, run a `DROP DATABASE` command, and close the connection
const loadSSLCredentials = require('./utils/loadSSLCredentials'); // Loads a .key and .crt file. Resolves a {key, cert} credentials object (used to start HTTPS server)
const passportJWTMiddleware = require('./utils/passportJWTMiddleware'); // For JWT auth
const resolveRelativePath = require('./utils/resolveRelativePath'); // Takes a rootDir and filePath. If filePath is absolute, return it as-is. Otherwise, return filePath relative to rootPath.
const startHTTPServer = require('./utils/startHTTPServer');
const stopHTTPServer = require('./utils/stopHTTPServer');
const getBaseConfig = require('./getBaseConfig'); //  Default config values

class NRBP extends EventEmitter {
  config = getBaseConfig();
  env = process.env['NODE_ENV'];
  isProductionEnv = this.env === 'production';
  isNotProductionEnv = !this.isProductionEnv;
  isTestEnv = this.env === 'test';
  isNotTestEnv = !this.isTestEnv;
  express = express;
  objection = objection;
  passport = passport;
  command = 'start';
  commandArgs = [];

  app = express();
  httpServers = []; // Running HTTP/HTTPS servers go here. Needed for teardown (see `this.destroy`).
  seeds = [];
  apiDefinitions = [];

  modelDefinitions = [];
  modelRegistry = new Map(); // Used to lookup models by their name
  models = {}; // Used to access model classes in application code

  controllerDefinitions = [];
  controllers = {};

  knexMigrationsEnabled = false;
  knexMigrationsConfig = null;
  knexSeedsEnabled = false;
  knexSeedsConfig = null;

  // For convenience
  Router = PromiseRouter;
  noop = function noop() {};

  _useConfigObjects(configObjects) {
    const customConfig = merge({}, ...configObjects);
    let config = this.config;

    if(!customConfig.rootDir) throw new Error('config.rootDir is required.');

    if(typeof customConfig.database === 'string') {
      const dbName = customConfig.database;
      customConfig.database = config.database;
      customConfig.database.connection.database = dbName;
    }

    const finalConfig = this.config = merge(config, customConfig);

    if(finalConfig.publicDir) finalConfig.publicDir = this.projectFile(finalConfig.publicDir);
    if(finalConfig.logFile) finalConfig.logFile = this.projectFile(finalConfig.logFile);

    return finalConfig;
  }

  constructor(...configObjects) {
    super();
    bindMethods(this); // Bind all of this instance's methods.
    const config = this._useConfigObjects(flatten(configObjects));

    this.jwtSecret = config.jwtSecret;
    this.sessionMiddleware = session({
      cookie: {},
      saveUninitialized: false,
      resave: false,
      secret: config.sessionSecret || uuidv4(),
    });
    this._setupLogging();

    const processExitHandler = async (error) => {
      await this.destroy();
      if(error) console.log(error);
      process.exit(error ? 1 : 0);
    };

    process.on('exit', processExitHandler);
    process.on('SIGINT', processExitHandler); // Catches ctrl+c
    process.on('SIGUSR1', processExitHandler); // SIGUSR1 and SIGUSR2 are for `kill pid` (ex: nodemon restart)
    process.on('SIGUSR2', processExitHandler);
    process.on('uncaughtException', processExitHandler);

    this.emitSelf('init');
  }

  emitSelf(eventId) {
    return this.emit(eventId, this);
  }

  _setupLogging() {
    const { config } = this;
    const {
      logFile,
      logLevel,
      fileLogLevel=logLevel,
      consoleLogLevel=logLevel,
    } = config;

    if(logFile) {
      mkdirp.sync(path.dirname(config.logFile));
      this.fileLogStream = {
        type: 'rotating-file',
        level: fileLogLevel,
        path: logFile,
        period: '1d',
        count: 3,
      };
    }

    const prettyStdOut = new PrettyStream({ mode: 'short' });
    prettyStdOut.pipe(process.stdout);
    this.consoleLogStream = {
      level: consoleLogLevel,
      type: 'raw',
      stream: prettyStdOut
    };

    const { fileLogStream, consoleLogStream } = this;
    const logStreams = this.logStreams = [];
    const requestLogStreams = this.requestLogStreams = [];

    if(this.isProductionEnv) {
      if(fileLogStream) {
        logStreams.push(fileLogStream);
        requestLogStreams.push(fileLogStream);
      }
    } else if(this.isTestEnv) {
      logStreams.push(fileLogStream);
      requestLogStreams.push(fileLogStream);
    } else {
      logStreams.push(fileLogStream, consoleLogStream);
      requestLogStreams.push(fileLogStream);
    }

    if(this.requestLogStreams.length) {
      this._expressBunyanMiddleware = expressBunyanLogger({
        name: config.name,
        streams: requestLogStreams,
      });
    }

    this.log = bunyan.createLogger({ name: config.name, streams: this.logStreams });
  }

  withArgv(argv) {
    let [command, ...args] = argv.slice(2);
    if(command) this.withCommand(command, ...args);
    return this;
  }

  withCommand(command, ...args) {
    this.command = command;
    this.commandArgs = args;
    return this;
  }

  // Returns `filePath` if it is absolute. Otherwise, resolves it relative to `config.rootDir`
  projectFile(filePath) {
    return resolveRelativePath(this.config.rootDir, filePath) ;
  }

  // Resolve a user using JWT payload object (used in this._applyExpressUtilityMiddleware)
  async lookupUserfromAuthToken(jwtPayload) {
    const { modelId } = jwtPayload;

    if(!modelId) {
      this.log.warn('Received JWT with missing modelId');
      return null;
    }

    const Model = this.getModelClassByModelId(modelId);
    if(!Model) {
      this.log.warn(`Received JWT with unknown modelId "${modelId}"`, this.modelRegistry);
      return null;
    }

    if(!Model.fromAuthToken) {
      throw new Error(`Model "${modelId}" must have a static \`fromAuthToken\` method.`);
    }

    // Find the specific model instance the JWT references
    return Model.fromAuthToken(jwtPayload);
  }

  registerModel(Model) {
    const modelId = Model.modelId;
    if(this.modelRegistry.has(modelId)) {
      if(this.modelRegistry.get(modelId) === Model) return;
      throw new Error(`Duplicate model IDs detected. A model with the modelId "${modelId}" already exists.\nAdd a static modelId getter to use a custom modelId.`);
    }
    this.modelRegistry.set(modelId, Model);
    this.models[modelId] = Model;
    this.log.debug(`Model "${modelId}" registered.`);
  }

  registerController(Controller) {
    const controllerId = Controller.controllerId;
    if(this.controllers[controllerId]) {
      if(this.controllers[controllerId] === Controller) return;
      throw new Error(`Duplicate controller IDs detected. A controller with the controllerId "${controllerId}" already exists.\nAdd a static controllerId getter to use a custom controllerId.`);
    }
    this.controllers[controllerId] = new Controller();
    this.log.debug(`Controller "${controllerId}" registered.`);
  }

  resolveModelClass(Model) {
    if(typeof Model === 'string') return this.getModelClassByModelId(Model);
    return Model;
  }

  getModelClassByModelId(modelId) {
    return this.modelRegistry.get(modelId);
  }

  _applyExpressUtilityMiddleware() {
    const { config, app, passport, log } = this;
    this.emitSelf('before:middleware');
    log.debug('Applying express middleware.');

    app.use(this.sessionMiddleware);

    if(this._expressBunyanMiddleware) {
      app.use(this._expressBunyanMiddleware);
    }

    if(this.isNotProductionEnv && this.isNotTestEnv) {
      app.use(require('morgan')('dev'));
    }

    // Allow cross-origin requests if `config.cors` is `true`.
    if(config.cors) app.use(require('cors')());

    // Parse JSON and form request bodies.
    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(bodyParser.json());

    // Adds `res.success` and `res.fail` utility methods.
    app.use(require('./utils/envelopeMiddleware')());

    // Lookup users by the JWT in their request header.
    app.use(passportJWTMiddleware(passport, this.jwtSecret, jwtPayload =>
      this.lookupUserfromAuthToken(jwtPayload).catch((error) => {
        log.warn('Error while looking up user from JWT:', error);
        return null;
      })
    ));

    // Serve files from `config.publicDir`.
    if(config.publicDir) {
      log.debug(`Hosting static files in "${config.publicDir}"`);
      app.use(express.static(config.publicDir));
    }

    this.emitSelf('after:middleware');
  }

  withKnexMigrations(directory='migrations', knexMigrationsConfig={}) {
    if(this.knexMigrationsEnabled) throw new Error('Multiple migration configurations not yet supported.');
    const { rootDir } = this.config;

    this.knexMigrationsEnabled = true;
    knexMigrationsConfig = Object.assign({ tableName: 'migrations' }, knexMigrationsConfig);
    knexMigrationsConfig.directory = this.projectFile(directory);
    this.knexMigrationsConfig = knexMigrationsConfig;

    return this;
  }

  withKnexSeeds(directory='seeds', knexSeedsConfig={}) {
    if(this.knexSeedsEnabled) throw new Error('Multiple migration configurations not yet supported.');
    const { rootDir } = this.config;

    this.knexSeedsEnabled = true;
    directory = this.projectFile(directory);
    this.knexSeedsConfig = Object.assign({}, knexSeedsConfig, { directory });

    return this;
  }

  withSeeds(...seedFns) {
    this.seeds.push(...flatten(seedFns));
    return this;
  }

  // Add model definitions
  withModels(...modelDefinitionFns) {
    this.modelDefinitions.push(...flatten(modelDefinitionFns));
    return this;
  }

  // Add api definitions
  withApi(prefix, definitionFn) {
    if(arguments.length === 1 && typeof prefix === 'function') {
      definitionFn = prefix;
      prefix = '/api';
    }
    this.apiDefinitions.push({prefix, definitionFn});
    return this;
  }

  withSocket(socketBody) {
    this.socketBody = socketBody;
    return this;
  }

  // Add model definitions
  withControllers(...controllerDefinitionFns) {
    this.controllerDefinitions.push(...flatten(controllerDefinitionFns));
    return this;
  }

  async _startWebserver() {
    const { config, log, socketBody } = this;
    const { http, https } = config;

    log.debug('Starting web servers.');
    // Apply commonly needed Express middleware (bodyParser, cors, etc).
    this._applyExpressUtilityMiddleware();
    // Expose Express middleware
    this.middleware = require('./middleware')(this);

    // Resolve controllers (parallel)
    log.debug(`Resolving controllers.`);
    await Promise.all(
      this.controllerDefinitions.map(async (controllerDefinitionFn) => {
        const controllerClasses = flatten(await controllerDefinitionFn(this));
        controllerClasses.forEach(this.registerController);
      })
    );

    // Resolve API routers (parallel) and pass them into the express app. Each api definition
    // function is passed the app context.
    log.debug(`Resolving API.`);
    await Promise.all(
      this.apiDefinitions.map(async ({prefix, definitionFn}) => {
        this.app.use(prefix, await definitionFn(this));
      })
    );

    // Express default error handler
    this.app.use((error, req, res, next) => {
      log.error('Unhandled', error);
      error = error || new Error('Internal server error');
      return res.fail({...error, error: error.message}, error.status || 500);
    });

    if(https) {
      log.debug('Starting HTTPS server.')
      try {
        const httpsServer = await this._startSecureServer();
        this.httpsServer = httpsServer;
        this.httpServers.push(httpsServer);
        log.info(`Listening on port ${this.config.httpsPort} ( HTTPS )`);
      } catch(error) {
        log.warn('Failed to start HTTPS Server:', getErrorMessage(error));
      }
    }

    if(http) {
      log.debug('Starting HTTP server.')
      try {
        const httpServer = await this._startInsecureServer();
        this.httpServer = httpServer;
        if(socketBody) {
          this._startSocketConnection();
        }
        this.httpServers.push(httpServer);
        log.info(`Listening on port ${this.config.port} ( HTTP )`);
      } catch(error) {
        log.warn('Failed to start HTTP Server:', getErrorMessage(error));
      }
    }
  }

  async runSeeds() {
    this.log.info('Running seeds.');

    let i = 0;
    for(let seedFn of this.seeds) { // run seeds in series
      const name = seedFn.name || `seed-${i}`;
      try {
        await seedFn(this);
        this.log.debug(`Seed "${name}" ran.`);
      } catch(error) {
        this.log.warn(`Seed "${name}" failed:`, error);
      }
      i++;
    }
  }

  async start() {
    const { config, log, seeds, command, commandArgs } = this;
    const commandIs = (...commands) => commands.includes(command);
    const hasArg = (arg) => commandArgs.includes(arg);
    this.emit('starting');
    log.info(commandArgs.length ?
      `Starting with command "${command}" and args ${commandArgs.join(', ')}. (${version})` :
      `Starting with command "${command}". (${version})`
    );

    if(!this.jwtSecret) {
      this.jwtSecret = await this._loadJWTSecret();
    }

    if(commandIs('start')) {
      if(hasArg('clear')) await this.clearDatabase();
      await this._startDatabase();
      if(hasArg('migrate')) await this.knexCommand(['migrate', 'latest']);
      if(hasArg('knex-seed')) await this.knexCommand(['seed', 'run']);
      if(hasArg('seed')) await this.runSeeds();
      await this._startWebserver();
      log.info('Started successfully.');
      this.emit('started');
      return this;
    } else {
      if(commandIs('knex')) {
        await this._startDatabase();
        await this.knexCommand(commandArgs);
      } else {
        if(commandIs('clear') || hasArg('clear')) await this.clearDatabase();
        await this._startDatabase();
        if(commandIs('migrate') || hasArg('migrate')) await this._runKnexMigrations();
        if(commandIs('seed') || hasArg('seed')) await this.runSeeds();
      }
      log.info('Finished.');
      await this.destroy();
    }
  }

  _startSocketConnection() {
    const { httpServer, sessionMiddleware, socketBody, log } = this;
    this.socketMiddleware = require('./socketMiddleware')(this);

    log.debug('Starting socket.io connection.');
    this.io = require('socket.io')(httpServer);
    this.io.use(require('socket.io-express-session')(sessionMiddleware));

    if(socketBody) {
      socketBody(this);
    }
  }

  async _loadJWTSecret() {
    const { log } = this;
    const jwtSecretFile = this.projectFile(this.config.jwtSecretFile);

    if(await exists(jwtSecretFile)) {
      const secret = await readFile(jwtSecretFile, 'utf8');
      return secret;
    } else {
      log.info(`JWT secret not found. Generating new secret.`);
      const jwtSecret = uuidv4();
      try {
        await writeFile(jwtSecretFile, jwtSecret, 'utf8');
        log.debug(`Secret generated and saved to "${jwtSecretFile}".`);
      } catch(error) {
        log.warn('Failed to write JWT secret to file. Auth sessions will work, but they will expire after the next server restart.', error);
      }

      return jwtSecret;
    }
  }

  async _startDatabase() {
    const { log } = this;
    if(this.knex) return;

    log.debug('Connecting to database.');
    // Create database if it doesn't exist. Then connect to it.
    this.knex = await this._createDatabaseConnection();

    this.objection.Model.knex(this.knex);

    // Model class is just an Objection Model
    this.Model = require('./Model')(this);

    // Controller is a plain javascript class with eagerly bound methods
    this.Controller = require('./Controller')(this);

    // Expose class decorators
    this.decorators = require('./decorators')(this);

    // Resolve Model classes (parallel). Each model definition function is
    // passed the app context. The models are then registered by their name.
    log.debug(`Resolving models.`);
    await Promise.all(
      this.modelDefinitions.map(async (modelDefinitionFn) => {
        const modelClasses = flatten(await modelDefinitionFn(this));
        modelClasses.forEach(this.registerModel);
      })
    );
  }

  async _createDatabaseConnection() {
    const knexOptions = Object.assign({},
      this.config.database,
      this.objection.knexSnakeCaseMappers(),
    );

    let knex = createKnex(knexOptions);
    const dbExists = await testDatabaseConnection(knex);

    if(!dbExists) {
      const dbName = knexOptions.connection.database;
      this.log.info(`Creating missing database "${dbName}".`);
      await knex.destroy();
      await createDatabase(knexOptions);
      knex = createKnex(knexOptions);
    }

    return knex;
  }

  async knexCommand(args=[]) {
    const [ subcommandName, ...subcommandArgs ] = args;

    if(subcommandName === 'migrate') {
      await this._knexMigrationCommand(subcommandArgs);
    } else if(subcommandName === 'seed') {
      await this._knexSeedCommand(subcommandArgs);
    } else {
      log.warn(`Invalid knex command "${subcommandName}".`);
    }
  }

  async _knexMigrationCommand(args=[]) {
    const [ knexCommandName='latest', ...knexCommandArgs ] = args;
    const {
      knex,
      knexMigrationsEnabled,
      knexMigrationsConfig,
      log,
    } = this;
    if(!knexMigrationsEnabled) throw new Error('You cannot use knex migrations without first running `withKnexMigrations` on your NRBP instance.');

    const knexMigrationCommands = {
      latest() {
        log.info('Running knex migrations.');
        return this.knex.migrate.latest(knexMigrationsConfig);
      },
      create(...nameParts) {
        const migrationName = nameParts.join('_').toLowerCase();
        log.info(`Creating knex migration "${migrationName}".`);
        return knex.migrate.make(migrationName, knexMigrationsConfig);
      },
      rollBack() {
        log.info('Rolling back knex migrations.');
        return knex.migrate.rollback(knexMigrationsConfig);
      },
    };
    knexMigrationCommands.make = knexMigrationCommands.create; // add alias for compatbility with knex's terminalogy

    if(knexMigrationCommands.hasOwnProperty(knexCommandName)) {
      await knexMigrationCommands[knexCommandName].apply(this, knexCommandArgs);
    } else {
      log.warn(`Invalid knex migration command "${knexCommandName}".`);
    }
  }

  async _knexSeedCommand(args=[]) {
    const [ knexCommandName='run', ...knexCommandArgs ] = args;
    const {
      knex,
      knexSeedsEnabled,
      knexSeedsConfig,
      log,
    } = this;
    if(!knexSeedsEnabled) throw new Error('You cannot use knex seeds without first running `withKnexSeeds` on your NRBP instance.');

    const knexSeedCommands = {
      run() {
        log.info('Running knex seeds.');
        return knex.seed.run(this.knexSeedsConfig);
      },
      create(...nameParts) {
        log.info(`Creating knex seed "${seedName}".`);
        const seedName = nameParts.join('')
        return knex.seed.make(seedName, knexMigrationsConfig);
      },
    };
    knexSeedCommands.make = knexSeedCommands.create; // add alias for compatbility with knex's terminalogy

    if(knexSeedCommands.hasOwnProperty(knexCommand)) {
      await knexSeedCommands[knexCommandName].apply(this, knexCommandArgs);
    } else {
      log.warn(`Invalid knex seed command "${knexCommandName}"`);
    }
  }

  _runKnexMigrations() {
    const { knexMigrationsEnabled, knexMigrationsConfig } = this;
    if(!knexMigrationsEnabled) throw new Error('You must run `withKnexMigrations` before running knex migrations.');

    this.log.info('Running knex migrations.');
    return this.knex.migrate.latest(knexMigrationsConfig);
  }

  _runKnexSeeds() {
    if(!this.knexSeedsEnabled) return null;
    return this.knex.seed.run(this.knexSeedsConfig);
  }

  // Drops all tables in the database. Chainable.
  async clearDatabase() {
    if(this.isProductionEnv) {
      this.log.error('WARNING: `clearDatabase` is unavailable in production environments (Ignoring call).');
      return this;
    }
    this.log.info('Clearing database.');
    const { knex } = this;

    try {
      await dropDatabase(this.config.database);
    } catch(error) {
      this.log.error(`Failed to drop database`, error);
    }

    return this;
  }

  // Create and start HTTP server. Resolves the server.
  async _startInsecureServer() {
    const { port } = this.config;
    if(!port) throw new Error('config.port is missing');

    return startHTTPServer({
      app: this.app,
      protocol: 'http',
      port: this.config.port,
    });
  }

  // Create and start HTTPS server. Resolves the server.
  async _startSecureServer() {
    const { httpsPort, sslKeyPath, sslCertPath } = this.config;
    if(!httpsPort) throw new Error('config.httpsPort is missing.');
    if(!sslKeyPath) throw new Error('config.sslKeyPath is missing.');
    if(!sslCertPath) throw new Error('config.sslCertPath is missing.');

    return startHTTPServer({
      app: this.app,
      protocol: 'https',
      port: httpsPort,
      credentials: await loadSSLCredentials(
        this.projectFile(this.config.sslKeyPath),
        this.projectFile(this.config.sslCertPath)
      ),
    });
  }

  // Close HTTP and HTTPS servers
  async _stopServers() {
    if(this.httpServers.length) {
      this.log.debug('Stopping servers.');
      await Promise.all(this.httpServers.map(stopHTTPServer));
      this.httpServers = [];
    }
  }

  startTransaction(fn) {
    if(fn) {
      return this.objection.transaction(this.knex, fn);
    } else {
      return this.objection.transaction.start(this.knex);
    }
  }

  // Close servers and destroy the database connection
  async destroy() {
    await this._stopServers();
    if(this.knex) { // close database connection
      this.log.debug('Destroying database connection.');
      await this.knex.destroy();
      this.knex = null;
    }
  }

  getTestUtils() {
    if(!this.testUtils) {
      this.testUtils = require('./testUtils')(this);
    }
    return this.testUtils;
  }
}

module.exports = NRBP;
