module.exports = context => {

  const filterAccess = require('./filterAccess')(context);

  return (...modelClasses) => {
    // transform the array of model classes or model type strings into a set of just model type strings
    const blockedmodelIds = new Set(
      modelClasses.map(Model => context.resolveModelClass(Model).modelId)
    );

    return filterAccess(
      (user) => !blockedmodelIds.has(user.modelId)
    )();
  };

};
