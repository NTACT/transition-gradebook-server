module.exports = (context) => ({
  fileUpload: require('./fileUpload')(context),
  filterAccess: require('./filterAccess')(context),
  getUser: require('./getUser')(context),
  login: require('./login')(context),
  onlyAllow: require('./onlyAllow')(context),
  onlyBlock: require('./onlyBlock')(context),
  requireAuthToken: require('./requireAuthToken')(context),
});
