module.exports = context => {

  const filterAccess = require('./filterAccess')(context);

  return (...modelClasses) => {
    // transform the array of model classes or model type strings into a set of just model type strings
    const allowedModelIds = new Set(
      modelClasses.map(Model => context.resolveModelClass(Model).modelId)
    );

    return filterAccess(
      (user) => allowedModelIds.has(user.modelId)
    )();
  };

};
