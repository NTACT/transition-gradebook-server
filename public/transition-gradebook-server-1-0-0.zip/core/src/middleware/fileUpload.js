module.exports = context => {
  const busboyBodyParser = require('busboy-body-parser');
  const mime = require('mime-types');

  // Make sure the upload includes a file
  const requireFile = (req, res, next) => {
    if(typeof req.files.file !== 'object') {
      // throw new Error('Missing file!');
      return res.status(400).end('Missing file!');
    }
    next();
  };

  // Make sure the file is of a certain type
  const allowFileByMimeType = validMimeTypes => validMimeTypes && validMimeTypes.length ?
    (req, res, next) => {
      const { file } = req.files;
      const isValidType = validMimeTypes.some(type => type === file.mime);

      if(!isValidType) return next(new Error(`Invalid file type "${file.mime}". Valid types: ${types.join(', ')}.`));
      next();
    } :
    (req, res, next) => next();

  return (types=[]) => {
    types = types.map(type => mime.lookup(type));
    return [
      busboyBodyParser(),
      requireFile,
      allowFileByMimeType(types),
    ];
  };
};
