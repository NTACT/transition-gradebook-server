module.exports = context => {

  const jwt = require('jsonwebtoken');
  const getErrorMessage = require('../utils/getErrorMessage');
  const { config } = context;

  return (Model, options={}) => {

    // Allow options to be statically set on the model or passed in the `options` object
    // Default values are in `config` are used if not present on `Model` or `options` (exluding `success`/`fail`)
    const { passUserThrough = false, passErrorThrough = false, caseSensitive = true, eager } = options;
    const usernameField = options.usernameField || Model.usernameField || config.defaultUsernameField;
    const invalidUsernameMessage = options.invalidUsernameMessage || Model.invalidUsernameMessage || config.defaultInvalidUsernameMessage;
    const invalidPasswordMessage = options.invalidPasswordMessage || Model.invalidPasswordMessage || config.defaultInvalidPasswordMessage;
    const missingUsernameMessage = options.missingUsernameMessage || Model.missingUsernameMessage || config.defaultMissingUsernameMessage;
    const missingPasswordMessage = options.missingPasswordMessage || Model.missingPasswordMessage || config.defaultMissingPasswordMessage;

    return async (req, res, next) => {
      const { username, password } = req.body;
      if(!username) return handleFail(req, res, next, new Error(missingUsernameMessage));
      if(!password) return handleFail(req, res, next, new Error(missingPasswordMessage));
      let query = Model
        .query()
        .where(usernameField, caseSensitive ? username : username.toLowerCase())
        .first();

      if(eager) {
        query = query.eager(eager);
      }

      const user = await query;


      if(user) {
        if(!user.verifyPassword) throw new Error('You must provide a `verifyPassword` method on the model in order for login requests to function.\nDid you forget to use the `hasPassword` decorator on your model?');
        if(await user.verifyPassword(password)) {
          const authToken = user.toJWT();
          return handleSuccess(req, res, next, authToken, user);
        } else {
          return handleFail(req, res, next, new Error(invalidPasswordMessage));
        }
      } else {
        return handleFail(req, res, next, new Error(invalidUsernameMessage));
      }
    };

    function handleSuccess(req, res, next, authToken, user) {
      if(passUserThrough) {
        res.locals.loginResult = {
          success: true,
          error: null,
          user: user,
          authToken: authToken,
        };
        next();
      } else {
        res.success({authToken, user});
      }
    }

    function handleFail(req, res, next, error) {
      if(passErrorThrough) {
        res.locals.loginResult = {
          success: false,
          error: error,
          user: null,
          authToken: null,
        };
        return next();
      } else {
        return res.fail(getErrorMessage(error), 401);
      }
    }

    function defaultUserToJWT(modelId, user) {
      return {
        modelId,
        userId: user.id,
      };
    }
  };

};
