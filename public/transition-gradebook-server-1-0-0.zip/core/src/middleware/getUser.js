module.exports = (context) => {
  const requireAuthToken = require('./requireAuthToken')(context);

  return (userMapFn) => {
    if(typeof userMapFn === 'function') {
      // If a function is passed, pass the user in and respond with the result.
      // Useful in conjunction with Objection's $loadRelated method.
      // See: http://vincit.github.io/objection.js/#_s_loadrelated
      return [
        requireAuthToken(),
        async (req, res) => {
          res.success({user: await userMapFn(req.user)});
        },
      ];
    } else if(typeof userMapFn === 'string') {
      // If a string is passed, use it as a relation expression string
      // See: http://vincit.github.io/objection.js/#relationexpression
      return [
        requireAuthToken(),
        async (req, res) => {
          await req.user.$loadRelated(userMapFn);
          res.success({user: req.user});
        },
      ];
    } else {
      // If nothing is passed, return the user as-is.
      return [
        requireAuthToken(),
        (req, res) => {
          res.success({user: req.user});
        },
      ];
    }
  };
};
