module.exports = ({ config, passport }) => {

  return () => (req, res, next) => passport.authenticate('jwt', { session: false }, (error, user) => {
    if(error) return next(error);
    if(!user) return res.fail('You must be logged in to view this content.', 401);
    req.user = user;
    return next();
  })(req, res, next);

};
