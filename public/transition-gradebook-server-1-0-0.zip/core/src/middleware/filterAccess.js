module.exports = context => {

  const requireAuthToken = require('./requireAuthToken')(context);
  const defaultFailStatus = 403; // Forbidden
  const defaultFailMessage = 'You don\'t have permission to view this content';

  return checkAccessFn => ({ failStatus=defaultFailStatus, failMessage=defaultFailMessage, fail }={}) => {
    return [
      requireAuthToken(),
      async (req, res, next) => {
        const { user } = req;
        const accessGranted = user && await checkAccessFn(user);
        if(accessGranted) {
          return next();
        } else {
          return res.fail(new Error(failMessage), failStatus);
        }
      },
    ];
  };

};
