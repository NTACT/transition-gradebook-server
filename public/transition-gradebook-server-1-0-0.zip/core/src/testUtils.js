module.exports = context => {
  const { config } = context;
  const protocol = config.http ? 'http' : 'https';
  const port = protocol === 'http' ? (config.httpPort || config.port) : config.httpsPort;
  const host = 'localhost';
  const nodeFetch = require('node-fetch');

  function fetch(endpoint, options, authToken) {
    const port = config.httpPort || config.port;
    options = options || {};
    if(endpoint[0] !== '/') endpoint = '/' + endpoint;
    const url = `${protocol}://${host}:${port}/api${endpoint}`;
    return nodeFetch(url, {
      ...options,
      headers: {
        ...options.headers,
        'Authorization': authToken,
      },
    });
  }

  function post(endpoint, body, authToken) {
    return fetch(endpoint, {
      method: 'POST',
      body: body && JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json',
      },
    }, authToken);
  }

  function put(endpoint, body, authToken) {
    return fetch(endpoint, {
      method: 'PUT',
      body: body && JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json',
      },
    }, authToken);
  }

  function del(endpoint, options, authToken) {
    return fetch(endpoint, {
      method: 'DELETE',
      ...options,
    }, authToken);
  }

  async function login(endpoint, credentials, parseResponse=true) {
    const response = await post(endpoint, credentials);
    if(parseResponse) return response.json();
    return response;
  }

  return {
    nodeFetch,
    fetch,
    post,
    put,
    del,
    login,
    'delete': del,
  };
};
