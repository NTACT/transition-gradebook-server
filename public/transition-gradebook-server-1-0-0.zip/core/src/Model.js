module.exports = (context) => {
  const { flatten } = require('lodash');
  const jwt = require('jsonwebtoken');
  const enableHardName = require('./utils/enableHardName');
  const { DbErrors } = require('objection-db-errors');

  @enableHardName('modelId')
  class Model extends DbErrors(context.objection.Model) {
    static get autoload() {
      return this.relationList(this.ownRelations);
    }

    static get ownRelations() {
      if(!this._relations) {
        this._relations = Object.keys(this.relationMappings || {});
      }
      return this._relations;
    }

    static get relations() {
      const { tableName } = this;
      return `${tableName}.[${this.ownRelations.join(', ')}]`;
    }

    static fromAuthToken(jwtPayload) {
      const { userId } = jwtPayload;
      return this.query().where('id', userId).first();
    }

    static relationList(...values) {
      return `[${flatten(values).join(', ')}]`;
    }

    get modelId() {
      return this.constructor.modelId;
    }

    toJWTPayload() {
      return {
        modelId: this.modelId,
        userId: this.id,
      };
    }

    toJWT() {
      return 'JWT ' + jwt.sign(this.toJWTPayload(), context.jwtSecret);
    }
  }

  return Model;
};
