const NRBP = require('../index');
const fetch = require('node-fetch');
const rootDir = __dirname;

const testEnv = ({ protocol='http', logFn }={}) => {
  const httpPort = 8030;
  const httpsPort = 8031;
  const jwtSecret = require('uuid/v4')();

  return {
    // Get a usable URL from an endpoint string.
    getEndpoint(endpointStr) {
      const port = protocol === 'http' ? httpPort : httpsPort;
      return `${protocol}://localhost:${port}${endpointStr[0] === '/' ? '' : '/'}${endpointStr}`;
    },

    config: {
      rootDir,
      httpPort,
      httpsPort,
      jwtSecret,
      port: httpPort,
      logLevel: 'error',
      database: {
        connection: {
          database: 'nrbp_test',
          host: 'localhost',
          password: '',
        },
      },
    },
  };
};

const testModels = ({ Model }) => ([
  class User extends Model {
    static tableName = 'users';
  },

  class Post extends Model {
    static tableName = 'posts';
  },
]);

const testApi = ({ Router, models, middleware }) => (
  Router()
  .get('/success', (req, res) => res.success('success'))
  .get('/fail', (req, res) => res.fail('fail'))
  .get('/echo', (req, res) => res.success(req.body))
  .post('/login', middleware.login(models.User), (req, res) => {
    res.success({user: req.user});
  })
  .get('/users', async (req, res) => {
    res.success(await models.User.query());
  })
);

const liveTestInstance = async (options={}) => {
  const envResults = testEnv(options);
  envResults.nrbp = await new NRBP(envResults.config).withModels(testModels).withApi(testApi).start();
  return envResults;
};

module.exports = {
  NRBP,
  fetch,
  testEnv,
  testModels,
  testApi,
  liveTestInstance,
};
