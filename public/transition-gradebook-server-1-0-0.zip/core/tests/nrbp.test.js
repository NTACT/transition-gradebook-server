const { NRBP, fetch, testEnv, testModels, testApi, liveTestInstance } = require('./testUtils');

// Use this top-level variable for `new NRBP` assignments to automatically
// close its HTTP servers and database connections after the test ends.
let nrbp;
afterEach(async () => {
  if(nrbp) {
    await nrbp.destroy();
    nrbp = null;
  }
});

test('NODE_ENV should be "test"', () => expect(process.env['NODE_ENV']).toEqual('test'));

describe('NRBP', () => {

  test('Should be a function', () => {
    expect(typeof NRBP).toEqual('function');
  });

  test('Should be able to create an instance', () => {
    const { config } = testEnv({ silent: true });
    nrbp = new NRBP(config);
    expect(nrbp).toBeInstanceOf(NRBP);
  });

  test('Should be able to start successfully', async () => {
    const { config } = testEnv({ silent: true });
    nrbp = new NRBP(config);
    await nrbp.start();
  });

  test('Should be able to destroy the instance and start another with the same config without conflicts', async () => {
    const { config, getEndpoint } = testEnv({ silent: true });
    const nrbp1 = new NRBP(config);
    await nrbp1.start();
    await nrbp1.destroy();

    const nrbp2 = new NRBP(config);
    await nrbp2.start();
    await nrbp2.destroy();
  });

  describe('#withApi', () => {
    test('Should be chainable', () => {
      const { config, getEndpoint } = testEnv({ silent: true });
      nrbp = new NRBP(config);

      expect(nrbp).toEqual(nrbp.withApi('/api', ({Router}) => Router()));
    });

    test('Should respond to requests', async () => {
      const { config, getEndpoint } = testEnv({ silent: true });
      nrbp = new NRBP(config);
      const expectedResult = 'TEST RESULT';

      nrbp.withApi('/api', ({Router}) => {
        return Router().get('/test', (req, res) => res.success(expectedResult));
      });
      await nrbp.start();

      const response = await fetch(getEndpoint('/api/test'));
      expect(response.ok).toBeTruthy();
      const result = await response.text();
      expect(result).toEqual(expectedResult);
    });

    test('Should respond to requests at /api when no prefix is passed', async () => {
      const { config, getEndpoint } = testEnv({ silent: true });
      nrbp = new NRBP(config);
      const expectedResult = 'TEST RESULT';

      nrbp.withApi(/* should be same as '/api', */ ({Router}) => {
        return Router().get('/test', (req, res) => res.success(expectedResult));
      });
      await nrbp.start();

      const response = await fetch(getEndpoint('/api/test'));
      expect(response.ok).toBeTruthy();
      const result = await response.text();
      expect(result).toEqual(expectedResult);
    });

    test('Should respond to requests to multiple routers', async () => {
      const { config, getEndpoint } = testEnv({ silent: true });
      nrbp = new NRBP(config);
      const expectedResult1 = {testValue1: 'test1'};
      const expectedResult2 = {testValue2: 'test2'};

      await nrbp
        .withApi('/api1', ({Router}) =>
          Router().get('/test1', (req, res) => res.success(expectedResult1))
        )
        .withApi('/api2', ({Router}) =>
          Router().get('/test2', (req, res) => res.success(expectedResult2))
        )
        .start();

      const response1 = await fetch(getEndpoint('/api1/test1'));
      expect(response1.status).toEqual(200);
      const result1 = await response1.json();
      expect(result1).toEqual(expectedResult1);

      const response2 = await fetch(getEndpoint('/api2/test2'));
      expect(response2.status).toEqual(200);
      const result2 = await response2.json();
      expect(result2).toEqual(expectedResult2);
    });
  });

  describe('#withModels', () => {
    test('Should be chainable', () => {
      const { config, getEndpoint } = testEnv({ silent: true });
      nrbp = new NRBP(config);
      expect(nrbp).toEqual(nrbp.withModels(testModels));
    });

    test('Should make the models available through nrbp.models', async () => {
      const { config, getEndpoint } = testEnv({ silent: true });
      nrbp = await new NRBP(config).withModels(testModels).start();
      expect(typeof nrbp.models.User).toEqual('function');
    });
  });

});

describe('Model', () => {
  test('It should have an modelId that defaults to its class name', async () => {

  });
});

describe('middleware', () => {

  describe('#login', async () => {

  });

});
