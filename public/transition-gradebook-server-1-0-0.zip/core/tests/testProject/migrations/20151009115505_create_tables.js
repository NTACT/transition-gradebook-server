exports.up = async (knex) => {
  await knex.schema.createTableIfNotExists('users', table => {
    table.increments('id').unsigned().primary();
    table.string('email').notNull();
    table.string('password').notNull();
  });

  await knex.schema.createTableIfNotExists('admins', table => {
    table.increments('id').unsigned().primary();
    table.string('email').notNull();
    table.string('password').notNull();
  });
};

exports.down = async (knex) => {
  await knex.schema.dropTableIfExists('users');
  await knex.schema.dropTableIfExists('admins');
};
