const faker = require('faker');

const createUser = ({
  email=faker.internet.email(),
  password=faker.internet.password(),
}={}) => ({
  email,
  password,
});
const createAdmin = createUser;

// Setup valid/invalid user test credentials
const validUsername = 'valid_username@test.com';
const validPassword = 'val1d_p@ssword123';
const invalidUsername = 'invalid_username@test.com';
const credentials = {
  valid: {username: validUsername, password: validPassword},
  invalidUsername: {username: invalidUsername, password: validPassword},
  invalidPassword: {username: validUsername, password: 'invalidpassword'},
  missingUsername: {password: validPassword},
  missingPassword: {username: validUsername},
  missing: {},
};
const testUser = createUser({email: validUsername, password: validPassword});

// Setup valid/invalid admin test credentials
const validAdminUsername = 'valid_admin_username@test.com';
const validAdminPassword = 'val1d_admin_p@ssword123';
const invalidAdminUsername = 'invalid_admin_username@test.com';
const adminCredentials = {
  valid: {username: validAdminUsername, password: validAdminPassword},
  invalidUsername: {username: invalidUsername, password: validAdminPassword},
  invalidPassword: {username: validAdminUsername, password: 'invalidpassword'},
  missingUsername: {password: validAdminPassword},
  missingPassword: {username: validAdminUsername},
  missing: {},
};
const testAdmin = createAdmin({email: validAdminUsername, password: validAdminPassword});

const users = [
  createUser(),
  createUser(),
  createUser(),
  createUser(),
  testUser,
  createUser(),
  createUser(),
  createUser(),
  createUser(),
];

const admins = [
  createAdmin(),
  createAdmin(),
  createAdmin(),
  createAdmin(),
  testAdmin,
  createAdmin(),
  createAdmin(),
  createAdmin(),
  createAdmin(),
];

module.exports = {
  credentials,
  adminCredentials,
  users,
  admins,
};
