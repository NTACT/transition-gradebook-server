const NRBP = require('../../src/index');
const testData = require('./testData');

const baseConfig = {
  rootDir: __dirname,
  http: true,
  port: 8123,
  httpsPort: 8124,
  jwtSecret: 'test secret',
  logLevel: 'debug',
  database: 'nrbp_test_project',
};

module.exports = (config={}) => {
  return new NRBP(baseConfig, config)
  .withCommand('start', 'clear', 'migrate', 'seed')
  .withKnexMigrations('./migrations')
  .withSeeds(
    function createUsers({ models }) {
      return models.User.query().insert(testData.users);
    },
    function createAdmins({ models }) {
      return models.Admin.query().insert(testData.admins);
    },
  )
  .withControllers(({ Controller }) => [
    class AppController {
      static controllerId = 'AppController';
    },

    class AdminSiteController {
      static controllerId = 'AdminSiteController';
    },
  ])
  .withModels(({ Model, decorators }) => [ // Objection.js ORM models
    @decorators.hasPassword
    class User extends Model {
      static tableName = 'users';
    },

    @decorators.hasPassword
    class Admin extends Model {
      static tableName = 'admins';
    },
  ])
  .withApi(({ Router, middleware, models, controllers }) =>
    Router()
      .post('/login', middleware.login(models.User))
      .post('/admin/login', middleware.login(models.Admin))
      .get('/user', middleware.getUser())
      .get('/test', (req, res) => res.success()) // Test if the API is working
      .get('/testSeeds', async (req, res) => { // Test if seeds ran successfully
        const user = await models.User.query().where('email', testData.credentials.valid.username).first();
        expect(user).toBeTruthy();
        res.success({user});
      })
      .get('/testControllerAccess', (req, res) => { // Make sure controllers are accessable from the API
        expect(controllers).toBeTruthy();
        expect(controllers.AppController).toBeTruthy();
        expect(controllers.AdminSiteController).toBeTruthy();
        res.success();
      })
      .get('/requireAuthToken', middleware.requireAuthToken(), (req, res) => { // Make sure a user is authenticated
        res.success();
      })
      .get('/onlyAllowUsers', middleware.onlyAllow(models.User), (req, res) => { // Make sure a user is a User model
        res.success();
      })
      .get('/onlyAllowAdmins', middleware.onlyAllow(models.Admin), (req, res) => { // Make sure a user is an Admin model
        res.success();
      })
      .use((error, req, res, next) => {
        if(!error) return next();
        res.fail(error, 555);
      })
  );
}
