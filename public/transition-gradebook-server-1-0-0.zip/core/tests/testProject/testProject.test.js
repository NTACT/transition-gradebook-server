
describe('test project', () => {
  const testData = require('./testData');
  const { users, admin, credentials, adminCredentials } = testData;
  let testUtils;
  let nrbp = null;
  let error = null;

  beforeAll(async () => {
    try {
      nrbp = require('./testApp')();
      testUtils = nrbp.getTestUtils();
      await nrbp.start();
    } catch(e) {
      error = e;
    }
  });

  afterAll(async () => {
    await nrbp.destroy();
  });

  test('Should start successfully', () => {
    if(error) throw error;
    if(!nrbp) throw new Error('Unknown error (nrbp is null?)');
  });

  test('Should respond to requests', async () => {
    const response = await testUtils.fetch('/test');
    expect(response.ok).toBeTruthy();
  });

  test('Should be able to access controllers from API', async () => {
    const response = await testUtils.fetch('/testControllerAccess');
    expect(response.ok).toBeTruthy();
  });

  test('Should have seeded a valid user', async () => {
    const response = await testUtils.fetch('/testSeeds');
    expect(response.ok).toBeTruthy();
    const { user } = await response.json();
    expect(user.email).toEqual(credentials.valid.username);
  });

  test('Should be able to login using POST /login', async () => {
    const { authToken, user } = await testUtils.login('/login', credentials.valid);

    expect(authToken).toBeTruthy();
    expect(user).toBeTruthy();
    expect(user.email).toEqual(credentials.valid.username);
  });

  test('Should fail login attempts with invalid usernames', async () => {
    const response = await testUtils.post('/login', credentials.invalidUsername);
    expect(response.ok).toBeFalsy();
  });

  test('Should fail login attempts with invalid passwords', async () => {
    const response = await testUtils.post('/login', credentials.invalidPassword);
    expect(response.ok).toBeFalsy();
  });

  test('Should fail login attempts with missing usernames', async () => {
    const response = await testUtils.post('/login', credentials.missingUsername);
    expect(response.ok).toBeFalsy();
  });

  test('Should fail login attempts with missing passwords', async () => {
    const response = await testUtils.post('/login', credentials.missingPassword);
    expect(response.ok).toBeFalsy();
  });

  test('Should fail login attempts with missing credentials', async () => {
    const response = await testUtils.post('/login', credentials.missing);
    expect(response.ok).toBeFalsy();
  });

  test('Should be able to login using multiple model classes', async () => {
    const { authToken, user } = await testUtils.login('/admin/login', adminCredentials.valid);

    expect(authToken).toBeTruthy();
    expect(user).toBeTruthy();
    expect(user.email).toEqual(adminCredentials.valid.username);
  });

  test('Should allow users to access /requireAuthToken', async () => {
    const { authToken } = await testUtils.login('/login', credentials.valid);
    const response = await testUtils.fetch('/requireAuthToken', null, authToken);
    expect(response.ok).toBeTruthy();
  });

  test('Should allow admins to access /requireAuthToken', async () => {
    const { authToken  } = await testUtils.login('/admin/login', adminCredentials.valid);
    const response = await testUtils.fetch('/requireAuthToken', null, authToken);
    expect(response.ok).toBeTruthy();
  });

  test('Should block access to /requireAuthToken when auth token is missing', async () => {
    const response = await testUtils.fetch('/requireAuthToken', null);
    expect(response.ok).toBeFalsy();
  });

  test('Should block access to /requireAuthToken when auth token is invalid', async () => {
    const response = await testUtils.fetch('/requireAuthToken', null, 'someinvalidauthtoken');
    expect(response.ok).toBeFalsy();
  });

  test('Should allow users to access /onlyAllowUsers', async () => {
    const { authToken } = await testUtils.login('/login', credentials.valid);
    const response = await testUtils.fetch('/onlyAllowUsers', null, authToken);
    expect(response.ok).toBeTruthy();
  });

  test('Should block admins from accessing /onlyAllowUsers', async () => {
    const { authToken } = await testUtils.login('/admin/login', adminCredentials.valid);
    const response = await testUtils.fetch('/onlyAllowUsers', null, authToken);
    expect(response.ok).toBeFalsy();
  });

  test('Should allow admins to access /onlyAllowAdmins', async () => {
    const { authToken } = await testUtils.login('/admin/login', adminCredentials.valid);
    const response = await testUtils.fetch('/onlyAllowAdmins', null, authToken);
    expect(response.ok).toBeTruthy();
  });

  test('Should block users from accessing /onlyAllowAdmins', async () => {
    const { authToken } = await testUtils.login('/login', credentials.valid);
    const response = await testUtils.fetch('/onlyAllowAdmins', null, authToken);
    expect(response.ok).toBeFalsy();
  });

  test('Should block access to /onlyAllowUsers when auth token is missing', async () => {
    const response = await testUtils.fetch('/onlyAllowUsers', null);
    expect(response.ok).toBeFalsy();
  });

  test('Should block access to /onlyAllowUsers when auth token is invalid', async () => {
    const response = await testUtils.fetch('/onlyAllowUsers', null, 'someinvalidauthtoken');
    expect(response.ok).toBeFalsy();
  });

  test('Should block access to /onlyAllowAdmins when auth token is missing', async () => {
    const response = await testUtils.fetch('/onlyAllowAdmins', null);
    expect(response.ok).toBeFalsy();
  });

  test('Should block access to /onlyAllowAdmins when auth token is invalid', async () => {
    const response = await testUtils.fetch('/onlyAllowAdmins', null, 'someinvalidauthtoken');
    expect(response.ok).toBeFalsy();
  });

  test('Should be able to request the user object using an auth token', async () => {
    const { authToken } = await testUtils.login('/login', credentials.valid);
    const response = await testUtils.fetch('/user', null, authToken);
    expect(response.ok).toBeTruthy();
    const { user } = await response.json();

    expect(user).toBeTruthy();
    expect(typeof user).toEqual('object');
    expect(user.email).toEqual(credentials.valid.username);
  });
});
