exports.up = function(knex) {
	return knex.schema.createTableIfNotExists('users', (table) => {
		table.increments('id').unsigned().primary();
		table.string('email').notNull();
    table.string('password').notNull();
	});
};

exports.down = function(knex) {
	return knex.schema.dropTableIfExists('users');
};
