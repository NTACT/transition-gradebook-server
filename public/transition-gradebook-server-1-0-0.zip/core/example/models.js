module.exports = ({Model, decorators}) => [

  @decorators.hasPassword()
  class User extends Model {
    static tableName = 'users';
    static passwordField = 'password';
  },

];
