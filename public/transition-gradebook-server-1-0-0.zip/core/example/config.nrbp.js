module.exports = {
  rootDir: __dirname,
  name: 'nrbp_example',
  http: true,
  database: {
    connection: {
      database: 'nrbp_example',
    },
  },
  timberId: '2085_f031654a05cb16cb:f1832c0f0cc5eedf8eb0340586c44f5e8ef5de2efaffa29db877b7a4cf12a3fa',
};
