
require('../src')
  .auto(__dirname, process.argv)
  .start() // Fire up the server
  .catch(error => console.log(error));
