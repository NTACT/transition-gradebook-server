module.exports = [

  function createUsers({ models }) {
    return models.User.query().insert([
      {email: 'user1@test.com', password: 'password1'},
      {email: 'user2@test.com', password: 'password2'},
      {email: 'user3@test.com', password: 'password3'},
    ]);
  },

];
