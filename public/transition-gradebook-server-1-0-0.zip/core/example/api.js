module.exports = ({ Router, middleware, models }) => (

  Router()
    .post('/login', middleware.login(models.User))
    .get('/user', middleware.getUser())
    .get('/users', async (req, res) => {
      res.success(await models.User.query()); // responds with a JSON array of users
    })
    .get('/user/:userId', async (req, res) => {
      const { userId } = req.params;
      const user = await models.User.query().where('id', userId);
      if(user) {
        res.success(user);
      } else {
        res.fail('User not found.', 404);
      }
    })

);
