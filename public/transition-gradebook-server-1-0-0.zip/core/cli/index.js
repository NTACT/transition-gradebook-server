#!/usr/bin/env node
require('babel-register');
require('./cli');
