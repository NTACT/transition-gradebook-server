const path = require('path');
const { existsSync, lstatSync } = require('fs');
const cwd = process.cwd();
const target = process.argv[2];
const rootDir = path.join(cwd, target);

const resolveFilePath = filePath => path.join(rootDir, filePath);
const isDirectory = file => existsSync(file) && lstatSync(file).isDirectory();
const findProjectFile = (...names) => names.map(resolveFilePath).find((path) => existsSync(path));

if(!isDirectory(rootDir)) {
  console.log(`Target is not a directory: "${rootDir}"`);
  process.exit(1);
}

const configFilePath = findProjectFile('config.js', 'config.json', 'config/index.js', 'config.nrbp.js');
const modelsFilePath = findProjectFile('models.js', 'models/index.js');
const controllersFilePath = findProjectFile('controllers.js', 'controllers/index.js');
const apiFilePath = findProjectFile('api.js', 'api/index.js');
const seedFilePath = findProjectFile('seeds.js', 'seeds/index.js');
const knexSeedFilePath = findProjectFile('knexSeeds');
const migrationsFilePath = findProjectFile('migrations', 'knexMigrations');

if(!configFilePath) {
  console.log(`Unable to find config in "${rootDir}"`);
  process.exit(1);
}

console.log(`Config found: "${configFilePath}"`);
const config = require(configFilePath);
const nrbpArgs = process.argv.slice(1);

const NRBP = require('../src');
const nrbp = new NRBP(config).withArgv(nrbpArgs);

if(modelsFilePath) {
  console.log(`Models found: "${modelsFilePath}"`);
  nrbp.withModels(require(modelsFilePath));
}

if(controllersFilePath) {
  console.log(`Controllers found: "${controllersFilePath}"`);
  nrbp.withControllers(require(controllersFilePath));
}

if(apiFilePath) {
  console.log(`API found: "${apiFilePath}"`);
  nrbp.withApi(require(apiFilePath));
}

if(migrationsFilePath) {
  console.log(`Migrations found: "${migrationsFilePath}"`);
  nrbp.withKnexMigrations(migrationsFilePath);
}

if(knexSeedFilePath) {
  console.log(`Knex seeds found: "${knexSeedFilePath}"`);
  nrbp.withKnexSeeds(knexSeedFilePath);
}

if(seedFilePath) {
  console.log(`Seeds found: "${seedFilePath}"`);
  nrbp.withSeeds(require(seedFilePath));
}

nrbp.start().catch(error => console.log(error));
