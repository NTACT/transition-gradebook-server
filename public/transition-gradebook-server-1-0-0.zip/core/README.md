# NRBP


A framework for quickly starting [Node.js](https://nodejs.org/en/) application servers using [Express](https://expressjs.com/), [Objection](http://vincit.github.io/objection.js) and [Passport](http://www.passportjs.org/). Written in ES6+.

## Getting Started

Install

```
yarn add https://github.com/Emberex/node-react-base-project
```

Create an `NRBP` instance with your configuration.

```javascript
const NRBP = require('nrbp');

const nrbp = new NRBP({
  httpsPort: 8010, // default
  port: 8000, // default
  publicDir: 'public',

  // For HTTPS
  sslKeyPath: 'sslcert/server.key', // default
  sslCertPath: 'sslcert/server.crt', // default

  database: {
    client: 'postgresql',
    connection: {
      database: 'db_name',
      user: process.env.USER, // default
      host: 'localhost', // default
      password: '', // default
    },
  },
});
```

Add model definitions (using [Objection](http://vincit.github.io/objection.js) Models).

```javascript
nrbp.withModels(({ Model, decorators }) => [
  @decorators.hasPassword
  class Admin extends Model {
    static tableName = 'admins';
    static usernameField = 'email';
    static passwordField = 'password';
  },

  @decorators.hasPassword // Automatic password hashing and hiding
  class User extends Model {
    static tableName = 'users';
    static usernameField = 'email';
    static passwordField = 'password';

    static get relationMappings() {
      return {
        posts: {
          relation: Model.HasManyRelation,
          modelClass: models.Post,
          join: {
            from: 'users.id',
            to: 'posts.authorId',
          },
        },
      };
    }
  },

  class Post extends Model {
    static tableName = 'posts';
  },
]);
```

Add an API (using [Express](https://expressjs.com/) Routers).

```javascript
nrbp.withApi('/api', ({ Router, models, middleware }) =>
  Router()
    // Expects { username, password } responds { authToken, user }
    .post('/login', middleware.login(models.User))
    // Protected endpoint
    .get('/secret', middleware.requireAuthToken(), (req, res) => {
      res.success('Access granted!');
    })
    // Admin-only protected endpoint
    .get('/admin/secret', middleware.onlyAllow(models.Admin), (req, res) => {
      res.success('Only admins can see this.');
    })
    // Easy database access
    .get('/users', async (req, res) => { // Public endpoint
      res.success(await User.query()); // responds with an array of users
    })
);
```

Add database migrations and seeds.

```javascript
nrbp.withKnexMigrations('./migrations');
nrbp.withSeeds([
  function createUsers({ models }) {
    return models.User.query().insert([
      {email: 'user1@test.com', password: 'password'},
      {email: 'user2@test.com', password: 'password'},
      {email: 'user3@test.com', password: 'password'},
    ]);
  },
  function createAdmins({ models }) {
    return models.Admin.query().insert([
      {email: 'admin@test.com', password: 'password'}
    ]);
  },
]);
```

Pass in a command.

```javascript
// clear the database, run migrations, run seeds, and start the server
nrbp.withCommand('start', 'clear', 'migrate', 'seed');

// OR

// Allow commands to be passed via the command line (ex. `node my-project start clear migrate seed`)
nrbp.withArgv(process.argv);
```

Start the server

```javascript
nrbp.start().catch(error => console.log(error));
```

## Configuration

TODO: put config value explanations here

## Api

#### Middleware

All middleware is available through `nrbp.middleware`.

TODO: put middleware explanations here

#### Model decorators

All decorators are available through `nrbp.decorators`.

TODO: put decorators explanations here

#### Events

`init` - Emitted immediately after internal constructor finishes.

`starting` - Emitted when the startup process begins.

`started` - Emitted after the startup process finishes.

`before:middleware` - Emitted before common express middleware is applied.

`after:middleware` - Emitted after common express middleware is applied.


## Development

### Setup

```
npm install
```

### Scripts

All scripts are run using `npm run`.

`test` - Runs all jest tests in the repo.

`build` - Builds the files in `src` and outputs them to `lib`.

`watch` - Watches the files in `src` rebuilding whenever anything changes.

#### License

TODO: Add license information.
