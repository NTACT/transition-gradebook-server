
// Only run tests in `__tests__` directories in the `src` directory
// with `.test.js` extensions.
module.exports = {
  rootDir: 'tests',
  testMatch: ['**/*.test.js?(x)'],
  reporters: [
    'jest-spec-reporter'
  ]
};
