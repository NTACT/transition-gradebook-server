
require('./server').start();
