module.exports = context => {
  const removeNullValues = require('../utils/removeNullValues');
  const { Controller, models } = context;
  const { SchoolSettings } = models;

  class SchoolSettingsController extends Controller {
    getSchoolSettings() {
      return SchoolSettings.query().select('*').first();
    }

    updateSchoolSettings(fields) {
      return SchoolSettings.query().patch(removeNullValues(fields)).first().returning('*');
    }
  }

  return SchoolSettingsController;
};
