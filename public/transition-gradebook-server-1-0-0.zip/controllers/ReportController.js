module.exports = context => {
  const { Controller } = context;

  context.reportUtils = require('../utils/reportUtils')(context);
  const reports = require('./reports')(context);
  const reportNames = Object.keys(reports);

  class ReportController extends Controller {
    runReport(name, options) {
      if(!reportNames.includes(name)) throw new Error(`Invalid report name "${name}"`);
      return reports[name](options);
    }
  }

  return ReportController;
};
