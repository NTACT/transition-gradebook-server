module.exports = context => {
  const { Controller, controllers, models } = context;

  const riskUtils = require('../utils/riskUtils');
  const { calcTermInfoRiskData } = riskUtils;

  class RiskDataController extends Controller {
    constructor() {
      super();
      // For testing
      Object.assign(this, riskUtils);
    }

    async getStudentRiskDataByTerms(termIds) {
      const schoolSettings = await controllers.SchoolSettingsController.getSchoolSettings();
      const terms = await models.Term.query()
        .whereIn('id', termIds)
        .eager('studentTermInfos(notPostSchool).student', {
          notPostSchool: query => query.where('gradeLevel', '!=', 'Post-school')
        });

      return terms.map(term => {
        term.students = term.studentTermInfos.map(
          studentTermInfo => ({
            ...studentTermInfo.student,
            ...calcTermInfoRiskData(schoolSettings, studentTermInfo)
          })
        );
        return term;
      });
    }
  }

  return RiskDataController;
};

