module.exports = context => {
  const removeNullValues = require('../utils/removeNullValues');
  const { Controller, models } = context;
  const { User } = models;

  class UserController extends Controller {
    getUsers() {
      return User.query().select('*');
    }

    createUser(fields) {
      return User.query().insert(fields).returning('*').first();
    }

    updateUser(userId, {firstName, lastName, email, password, admin}) {
      const fields = removeNullValues({
        firstName, lastName, email, password, admin
      });

      return User.query().patchAndFetchById(userId, fields);
    }

    deleteUser(userId) {
      return User.query().delete().where('id', userId);
    }

    getUser(email) {
      return User.query().where('email', email).first();
    }

    updatePassword(id, password) {
      return User.query().patch({password}).where('id', id);
    }
  }

  return UserController;
};
