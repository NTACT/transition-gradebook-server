module.exports = context => [
  require('./ActivityController')(context),
  require('./DisabilityController')(context),
  require('./DashboardController')(context),
  require('./SchoolYearController')(context),
  require('./StudentController')(context),
  require('./UserController')(context),
  require('./ReportController')(context),
  require('./ResetPasswordController')(context),
  require('./RiskDataController')(context),
  require('./SchoolSettingsController')(context),
];
