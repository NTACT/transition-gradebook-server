
module.exports = context => context.reportUtils.getSingleTermReportData;
