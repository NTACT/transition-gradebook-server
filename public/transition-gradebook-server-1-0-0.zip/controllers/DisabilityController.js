module.exports = context => {
  const { Controller, models } = context;
  const { Disability } = models;

  class DisabilityController extends Controller {
    getDisabilities() {
      return Disability.query().select('*');
    }
  }

  return DisabilityController;
};
