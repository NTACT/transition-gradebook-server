module.exports = {
  name: 'transition_gradebook',
  cors: false,
  debug: false,
  port: 8000,

  siteUrl: 'http://localhost:8000',

  database: {
    connection: {
      database: 'transition_gradebook',
      user: 'root',
      host: 'localhost',
      password: '',
    },
  },

  emailService: {
    host: '',       // 'smtp.gmail.com'
    port: '',       // 465
    secure: '',     // true for 465, false for other ports
    fromEmail: '',  // from_email@gmail.com
    auth: {
      user: '',     // auth_email@gmail.com
      pass: '',     // auth_email_password
    },
  },

  // These directories are relative to src
  jwtSecretFile: './.jwtsecret',
  logFile: './logs/logs.json',
  publicDir: './public',
  mediaDir: './public/media',
};
