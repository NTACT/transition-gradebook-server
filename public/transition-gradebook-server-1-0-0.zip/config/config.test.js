module.exports = {
  isTestConfig: true,
  port: 10000 + Math.floor(Math.random() * 40000),

  database: {
    connection: {
      database: 'transition_gradebook_test_' + Math.floor(Math.random() * 100000),
      user: 'james'
    },
  },

  emailService: {
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    fromEmail: 'transitiongradebook@gmail.com',
    auth: {
      user: 'transitiongradebook@gmail.com',
      pass: 'Y9vBAwS45YEt'
    }
  },
};
