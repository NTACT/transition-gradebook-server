module.exports = {

  database: {
    connection: {
      database: 'transition_gradebook',
      user: process.env.USER,
      host: 'localhost',
      password: '',
    },
  },

  emailService: {
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    fromEmail: 'transitiongradebook@gmail.com',
    auth: {
      user: 'transitiongradebook@gmail.com',
      pass: 'Y9vBAwS45YEt'
    }
  },

};
