module.exports = () => (req, res, next) => {
  if(!req.user || !req.user.admin) {
    return res.fail(new Error('Admin only.'), 401);
  }
  return next();
};