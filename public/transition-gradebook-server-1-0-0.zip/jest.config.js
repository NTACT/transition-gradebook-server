module.exports = {
  moduleDirectories: ['node_modules'],
  rootDir: 'tests',
  testMatch: ['**/*.test.js?(x)'],
};
