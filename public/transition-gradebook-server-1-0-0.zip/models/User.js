module.exports = context => {
  const { Model, models, decorators } = context;
  const { hasPassword } = decorators;

  @hasPassword
  class User extends Model {
    static tableName = 'users';
    static usernameField = 'email';
    static passwordField = 'password';

    static get jsonSchema() {
      return {
        type: 'object',
        required: ['firstName', 'lastName', 'email', 'password'],
        properties: {
          id: {type: 'integer'},
          firstName: {type: 'string', minLength: 2},
          lastName: {type: 'string', minLength: 2},
          email: {type: 'string', minLength: 6},
          password: {type: 'string', minLength: 8},
          admin: {type: 'boolean'},
        },
      };
    }

    async isEmailInUse(email) {
      return !!(await User.query().first().where('email', email));
    }

    async validateEmail(email) {
      if(email && (await this.isEmailInUse(email))) {
        throw new Error('A user with that email already exists.');
      }
    }

    async $beforeUpdate(opts) {
      await this.validateEmail(this.email);
    }

    async $beforeInsert(opts) {
      await this.validateEmail(this.email);
    }
  }

  return User;
};
